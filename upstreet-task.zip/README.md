# Upstreet Coding Challenge #

## To Check the functionality
npm run dev

##To run the unit test cases
npm test

