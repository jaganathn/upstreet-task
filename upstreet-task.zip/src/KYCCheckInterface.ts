/**
 * Data required for KYC check
 */
export interface KYCCheckInterface {
    "birthDate": Date,
    "givenName": string,
    "middleName": string,
    "familyName": string,
    "licenceNumber": string,
    "stateOfIssue": string,
    "expiryDate"?: Date
  };