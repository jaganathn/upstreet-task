/**
 * Making third party API call to check KYC details are valid or not.
 */
import {KYCCheckInterface} from '../KYCCheckInterface';

export async function KYCCheckAPI(requestParams: KYCCheckInterface):Promise<any>
{
    const url = 'australia-southeast1-reporting-290bc.cloudfunctions.net';
    const path = 'driverlicence';
    const token = '03aa7ba718da920e0ea362c876505c6df32197940669c5b150711b03650a78cf';

    const https = require('https');
    
    var jsonObject = JSON.stringify(requestParams);
     
    // prepare the header
    var postheaders = {
        'Content-Type' : 'application/json',
        'Content-Length' : Buffer.byteLength(jsonObject, 'utf8'),
        'Authorization': 'Bearer '+token
    };
     
    // the post options
    var optionspost = {
        host : url,
        port : 443,
        path : '/'+path,
        method : 'POST',
        headers : postheaders
    };
    
    const httpPost = (optionspost:any) => {
        return new Promise((resolve, reject) => {

                var reqPost =  https.request(optionspost, function(res:any) {
                    res.setEncoding('utf8');
                    let body = ''; 
                    res.on('data', (chunk:any) => body += chunk);
                    res.on('end', () => resolve(body));
                }).on('error', reject);
                
                // write the json data
                reqPost.write(jsonObject);
                reqPost.end();
                reqPost.on('error', function(e:any) {
                    console.error(e);
                });
                
        }).catch(err => console.error(err));
    };

    const apiResponse = await httpPost(optionspost);
    return apiResponse;
}


