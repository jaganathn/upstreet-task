/**
 * Validate the client input data provided for KYC Check
 */
const Joi = require('joi').extend(require('@joi/date'))

export function validateKYCData(requestParams: any)
{
	const JoiSchema = Joi.object({
        
        birthDate: Joi.date()
                .format('YYYY-MM-DD')
                .required(),

	givenName: Joi.string()
                .min(1)
                .max(100)
                .required(),

        middleName: Joi.string()
                .min(1)
                .max(100)
                .optional(),

        familyName: Joi.string()
                .min(1)
                .max(100)
                .required(),

        licenceNumber: Joi.string()
                .min(5)
                .max(30)
                .required(),

        stateOfIssue: Joi.string()
                .required().valid('NSW', 'QLD', 'SA', 'TAS', 'VIC', 'WA', 'ACT', 'NT'),

        expiryDate: Joi.date()
                .format('YYYY-MM-DD')
                .optional()
						
	}).options({ abortEarly: false });

	return JoiSchema.validate(requestParams)
    
}
