/**
 * It's a entry point of a application
 */

import {doKYCCheck} from './KYCCheck';

//Client input data
const formInputs = {
    "birthDate":  "1985-02-08",
    "givenName": "James",
    "middleName": "Robert",
    "familyName": "Smith",
    "licenceNumber": "94977000",
    "stateOfIssue": "NSW",
    "expiryDate":  "2020-01-22",
  };

  try{
    //calling function to do KYC Check
    doKYCCheck(formInputs);
  } catch(error:any){
    console.error('Error Occured: ', error.message);
}


