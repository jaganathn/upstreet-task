/**
 * function does KYC Check using third party API
 */

import {KYCCheckAPI} from './thirdparty/KYCCheckAPI';

import {KYCCheckInterface} from './KYCCheckInterface';
import {validateKYCData} from './validateKYCData';
import {handleKYCCheckResponse} from './handleKYCCheckResponse';

export async function doKYCCheck(formInputs: any)
{
    //extracting client provided data
    const requestParams:KYCCheckInterface = {
        "birthDate":  formInputs.birthDate,
        "givenName": formInputs.givenName,
        "middleName": formInputs.middleName,
        "familyName": formInputs.familyName,
        "licenceNumber": formInputs.licenceNumber,
        "stateOfIssue": formInputs.stateOfIssue,
        "expiryDate":  formInputs.expiryDate,
      };
    
    //validating the client data
    const response = validateKYCData(requestParams)

    if(response.error)
    {
        //if validation fails, displaying the errors
        console.log(response.error.details)
    }
    else
    {
        //If validation is success
        //Making API Call to do KYC Check
        try{
            let apiResponse = await KYCCheckAPI(requestParams);
            apiResponse = JSON.parse(apiResponse);
            
            let apiStatusCode:any = apiResponse['verificationResultCode'];
            //handling API Response
            let clientResponse = handleKYCCheckResponse(apiStatusCode);
            
            console.log(clientResponse);
            
        } catch(error:any){
            console.error('API Call Error: ', error.message);
        }
        
    }
    
}