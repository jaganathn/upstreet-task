/**
 * Unit test cases to test KYC Check response
 */
const expect = require('chai').expect;

import {handleKYCCheckResponse} from '../handleKYCCheckResponse';

describe('KYC Check Response', () => {
    let KYCCheckResponse:{[k:string]:any} = {};
	
	beforeEach(()=> {
		KYCCheckResponse = {
                "verificationDocumentResult": {
                    "type": "DriverLicenceResponse"
                },
                "verificationRequestNumber": 63744,
                "verificationResultCode": "Y"
		  };
	})

	afterEach(()=> {
		KYCCheckResponse = {}
	})

    it('KYC Check Is Success', () => {
        KYCCheckResponse.verificationResultCode= "Y";
        let response = handleKYCCheckResponse(KYCCheckResponse.verificationResultCode);
        expect(response.kycResult).to.be.true;
    });

	it('KYC Check Is Failed', () => {
        KYCCheckResponse.verificationResultCode= "N";
        let response = handleKYCCheckResponse(KYCCheckResponse.verificationResultCode);
		expect(response.kycResult).to.be.false;
    });

    it('KYC Check Server Error', () => {
        KYCCheckResponse.verificationResultCode= "S";
        let response = handleKYCCheckResponse(KYCCheckResponse.verificationResultCode);
        
		expect(response).to.include({ code: 'S', message: 'Server Error' });
    });

    it('KYC Check Document Error', () => {
        KYCCheckResponse.verificationResultCode= "D";
        let response = handleKYCCheckResponse(KYCCheckResponse.verificationResultCode);
        
		expect(response).to.include({ code: 'D', message: 'Document Error' });
    });
});