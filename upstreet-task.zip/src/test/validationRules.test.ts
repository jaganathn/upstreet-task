/**
 * Unit test cases to test client input data
 */

const expect = require('chai').expect;
const faker = require("faker");

import {validateKYCData} from '../validateKYCData';


describe('Form Input Validation Rules', () => {
    let formInputs:{[k:string]:any} = {};
	/*
	before(()=> {
		
	})

	after(()=> {	
		
	})*/

	beforeEach(()=> {
		formInputs = {
			"birthDate":  "1985-02-08",
			"givenName": faker.name.findName(),
			"middleName": faker.name.findName(),
			"familyName": faker.name.findName(),
			"licenceNumber": 'XYZSA'+faker.random.word(),
			"stateOfIssue": "NSW",
			"expiryDate":  "2020-01-22",
		  };
	})

	afterEach(()=> {
		formInputs = {}
	})

    it('valid birthDate', () => {
        let response = validateKYCData(formInputs);
		expect(response.error).to.be.an('undefined');
    });

	it('invalid birthDate', () => {
		formInputs.birthDate= "02-08-1985"
        let response = validateKYCData(formInputs);
		expect(response.error).to.be.an('error');
    });

	it('valid stateOfIssue', () => {
        let response = validateKYCData(formInputs);
		expect(response.error).to.be.an('undefined');
    });

	it('invalid stateOfIssue', () => {
		formInputs.stateOfIssue= "ABCD"
        let response = validateKYCData(formInputs);
		expect(response.error).to.be.an('error');
    });

	it('valid familyName', () => {
        let response = validateKYCData(formInputs);
		expect(response.error).to.be.an('undefined');
    });

	it('invalid familyName-more than 100 character', () => {
		//greater than
		formInputs.stateOfIssue= "dalksdjklasdjasdasljhdkljaksdjkasljdklasjdklasjdklasjdkljaskldjaskldjaskldjaskldsadasdasdasdasdasdasdasdqerowekvkljfklsdjf"
        let response = validateKYCData(formInputs);
		expect(response.error).to.be.an('error');
    });
    
	it('optional middleName', () => {
        let response = validateKYCData(formInputs);
		expect(response.error).to.be.an('undefined');
    });
});