/**
 * Handling API response
 * @param apiStatusCode 
 * @returns 
 */
export function handleKYCCheckResponse(apiStatusCode: any)
{
    let clientResponse: {[k: string]: any} = {};
    switch(apiStatusCode)
    {
        case 'Y':
            clientResponse.kycResult=true;
            break;
        
        case 'N':
            clientResponse.kycResult=false;
            break;

        case 'D':
            clientResponse.code=apiStatusCode;
            clientResponse.message="Document Error";
            break;

        case 'S':
            clientResponse.code=apiStatusCode;
            clientResponse.message="Server Error";
            break;
    }

    return clientResponse;
}